const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

const calendarContainer = document.querySelector('.calendar');


for (let monthIndex = 0; monthIndex < months.length; monthIndex++) {
    const monthDiv = document.createElement('div');
    monthDiv.classList.add('month');
    const monthHeader = document.createElement('h2');
    monthHeader.textContent = months[monthIndex];
    monthDiv.appendChild(monthHeader);

    const daysInMonth = new Date(2024, monthIndex + 1, 0).getDate();
    for (let day = 1; day <= daysInMonth; day++) {
        const dateBtn = document.createElement('button');
        dateBtn.classList.add('date-btn');
        dateBtn.textContent = day;
        dateBtn.addEventListener('click', () => openNotePopup(monthIndex, day));
        monthDiv.appendChild(dateBtn);
    }

    calendarContainer.appendChild(monthDiv);
}

const notePopup = document.getElementById('note-popup');
const noteTextarea = document.getElementById('note-text');
const saveNoteBtn = document.getElementById('save-note');

function openNotePopup(month, day) {
    notePopup.style.display = 'block';
    const savedNote = localStorage.getItem(`note_${months[month]}_${day}`);
    noteTextarea.value = savedNote || '';
    saveNoteBtn.onclick = () => saveAndClosePopup(month, day);
}

function saveAndClosePopup(month, day) {
    const note = noteTextarea.value;
    localStorage.setItem(`note_${months[month]}_${day}`, note);
    notePopup.style.display = 'none';
}
