h2 {
  text-align: center;
  }
#tagline {
  text-align: right;
  }
#contact {
  text-align: right;
  }

h1, #tagline, #contact {
  background-color: black;
  color:red;
  }