let value1 = 0;
let value2 = 0; 
let value3 = 0;
let value4 = 0;
let value5 = 0; 

function clicked ()
{}
  let selectedFace1 = document.querySelection('input[name="Question1"]:checked'); 
  let selectedFace2 = document.querySelection('input[name="Question2"]:checked'); 
  let selectedFace3 = document.querySelection('input[name="Question3"]:checked'); 
  let selectedFace4 = document.querySelection('input[name="Question4"]:checked'); 
  let selectedFace5 = document.querySelection('input[name="Question5"]:checked'); 

value1 = selectedFace1.value;
value2 = selectedFace2.value;
value3 = selectedFace3.value;
value4 = selectedFace4.value;
value5 = selectedFace5.value; 
 // Calculate average
let average = (value1 + value2 + value3 + value4 + value5) / 5;

// Create submit button 
let submitBtn = document.createElement("button");
submitBtn.innerHTML = "Submit";

// Add click event to button
submitBtn.addEventListener;"click", function(){
}
if(average === 1) {
  console.log("Hope is not a lottery ticket you buy with wishful thinking. It's a muscle you develop by daily courage, by the tough decisions you make every day to just show up and try again. It's the light that keeps illuminating the path forward, even when it's too dark to see. - Brené Brown"); 
} else if (average > 2 && average < 3) {
  console.log("We all have days where it feels like the world is conspiring against us. The toast burns, the train is late, and your boss gives you the side-eye. It's okay to not be okay on those days. Acknowledge the meh, accept it, and remember it doesn't define you.");
} else if (average >3 && average < 4) {
  console.log("You don’t have to be positive all the time. It’s perfectly okay to feel sad, angry, annoyed, frustrated, scared and anxious. Having feelings doesn’t make you a negative person. It makes you human. — Lori Deschene");
} else if (average >4 && average < 5) {
  console.log("Life is a tapestry woven with threads of light and shadow. Today, the light shines more brightly. Embrace the warmth of this day, let it illuminate the corners of your soul, and remember that even on darker days, the memory of this joy can be a guiding ember. - Maya Angelou"); 
  }
{}